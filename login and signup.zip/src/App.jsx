import { RouterProvider } from 'react-router-dom'
import './App.css'
import router from './Router'
import './assets/fonta/roboto.js'


function App() {

  return (
    <>
     <RouterProvider router = {router}/>
    </>
  )
}

export default App