import { createBrowserRouter } from "react-router-dom";
import Home from "../Pages/Home/Home";
import Root from "../Layouts/Root";
import LoginCard from "../Components/Login/LoginCard";
import { Grid } from "@mui/material";
import SignUp from "../Pages/Home/SignUp/SignUp";

const router = createBrowserRouter([
    {
        path:'/',
        element: <Root/>,
        children:[
            {
                path:'/',
                element:<Home/>
            },
            {
                path:'/login',
                element:<LoginCard/>
            }, 
            {
                path:'/signup',
                element: <SignUp/>
            }
        ]
    }
])

export default router