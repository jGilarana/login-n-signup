import { Link } from 'react-router-dom'
import './Home.css'

const Home = () => {
  return (
    <div className="home">
      <Link to={'/login'}><h1>Go to Login</h1> </Link>
    </div>
  )
}

export default Home
