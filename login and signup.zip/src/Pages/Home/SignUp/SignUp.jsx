import "./SignUp.css";
import {
  Card,
  CardContent,
  TextField,
  CardActions,
  Button,
  InputAdornment,
  Icon,
  IconButton,
  Divider,
  Typography,
} from "@mui/material";
import { blue } from "@mui/material/colors";
import { Link } from "react-router-dom";
import { Email, Lock, Visibility, VisibilityOff } from "@mui/icons-material";
import { useState } from "react";
import PersonIcon from '@mui/icons-material/Person';

const SignUp = () => {
  const [isVisible, setisVisible] = useState(false);
  return (
    <div className="sign-container">
      <Card
        className="signup"
        sx={{
          borderRadius: "20%",
          margin: "4vh",
          overflow: "auto",
          width: "50vw",
          height: "100%",
          textAlign: "center",
          maxWidth: "700px",
          backgroundColor: blue[300],
        }}
        raised={true}
      >
        <CardContent sx={{ margin: "5vw" }}>
          <Typography sx={{ marginBottom: "60px" }} variant="h3">
            Sign Up
          </Typography>
          <TextField
            sx={{ marginBottom: "3vh" }}
            fullWidth={true}
            label="Name"
            variant="standard"
            InputProps={{
              startAdornment : (
                <Icon>
                  <PersonIcon/>
                </Icon>
              )
            }}
          ></TextField>
          <TextField
            sx={{ marginBottom: "3vh" }}
            fullWidth={true}
            label="Surname"
            variant="standard"
          ></TextField>
          <TextField
            sx={{ marginBottom: "3vh" }}
            fullWidth={true}
            label="Put your favorite Phone Number"
            variant="filled"
          ></TextField>
          <TextField
            sx={{ marginBottom: "3vh" }}
            fullWidth={true}
            label="Email"
            variant="standard"
            InputProps={{
              startAdornment: (
                <InputAdornment>
                  <Icon>
                    <Email />
                  </Icon>
                </InputAdornment>
              ),
            }}
          ></TextField>
          <Link to={"/"}></Link>
          <TextField
            fullWidth={true}
            type={isVisible ? "text" : "password"}
            label="Password"
            variant="standard"
            InputProps={{
              startAdornment: (
                <InputAdornment>
                  <Icon>
                    <Lock />
                  </Icon>
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment>
                  <IconButton onClick={() => setisVisible(!isVisible)}>
                    {isVisible ? (
                      <Visibility sx={{ color: "red" }} />
                    ) : (
                      <VisibilityOff />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          ></TextField>
          <TextField
            fullWidth={true}
            type={isVisible ? "text" : "password"}
            label="Repeat your password"
            variant="standard"
            InputProps={{
              startAdornment: (
                <InputAdornment>
                  <Icon>
                    <Lock />
                  </Icon>
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment>
                  <IconButton onClick={() => setisVisible(!isVisible)}>
                    {isVisible ? (
                      <Visibility sx={{ color: "red" }} />
                    ) : (
                      <VisibilityOff />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          ></TextField>
          <p className="bornText">Select your born Date</p>
          <TextField
            fullWidth={true}
            variant="standard"
            type="date"
          ></TextField>
          <div className="gendering">
            <input type="radio" value="Male" name="gender" /> Male
            <input type="radio" value="Female" name="gender" /> Female
            <input type="radio" value="Other" name="gender" /> Other
          </div> <Divider></Divider>

          <CardActions sx={{ display: "flex", justifyContent: "flex-end" }}>
            <Link to={"/"}>
              <Button
                sx={{
                  marginTop: "60px",
                  position: "abolute",
                  right:'11.7vw'
                }}
                size="small"
                color="secondary"
                variant="contained"
              >
                Sign Up
              </Button>
            </Link>
          </CardActions>
        </CardContent>
      </Card>
    </div>
  );
};

export default SignUp;
