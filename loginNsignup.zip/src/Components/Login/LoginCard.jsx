import "./LoginCard.css";
import {
  Card,
  CardContent,
  TextField,
  CardActions,
  Button,
  InputAdornment,
  Icon,
  IconButton,
  Divider,
  Typography,
} from "@mui/material";
import { blue } from "@mui/material/colors";
import { Link } from "react-router-dom";
import { Email, Lock, Visibility, VisibilityOff } from "@mui/icons-material";
import { useState } from "react";

const LoginCard = () => {
  const [isVisible, setisVisible] = useState(false);

  return (
    <div className="container">
      <Card className="login"
        sx={{  
          borderRadius: "20%",
          margin: "4vh",
          overflow: "auto",
          width: "65vw",
          height: "100%",
          textAlign: "center",
          backgroundColor: 'aquamarine',
        }}
        raised={true}
      >
        <CardContent sx={{ margin: "2vw" }}>
          <Typography sx={{marginBottom:'60px'}} variant="h3">Login</Typography>
          <TextField 
            fullWidth={true}
            label="Email"
            variant="standard"
            InputProps={{
              startAdornment: (
                <InputAdornment>
                  <Icon>
                    <Email/>
                  </Icon>
                </InputAdornment>
              ),
            }}
          ></TextField>
          <Link to={"/"}>
            <p>He olvidado mi email</p>
          </Link>
          <TextField
            fullWidth={true}
            type={isVisible ? "text" : "password"}
            label="Contraseña"
            variant="standard"
            InputProps={{
              startAdornment: (
                <InputAdornment>
                  <Icon>
                    <Lock />
                  </Icon>
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment>
                  <IconButton onClick={() => setisVisible(!isVisible)}>
                    {isVisible ? (
                      <Visibility sx={{ color: "red" }} />
                    ) : (
                      <VisibilityOff />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          ></TextField>
          <Link to={"/"}>
            <p>He olvidado mi contraseña</p>
          </Link>

          <Divider></Divider>

          <CardActions sx={{ display: "flex", justifyContent: "flex-end" }}>
            <Link to={'/signup'}><Button
              sx={{ marginTop: "60px" }}
              size="small"
              color="secondary"
              variant="contained"
            >
              Registrarse
            </Button>
            </Link>
            <Link to={"/"}>
              <Button
               sx={{ marginTop: "60px", marginLeft: '20px' }}
                size="small"
                color="primary"
                variant="contained"
                margin="60px"
              >
                Login
              </Button>
            </Link>
           
          </CardActions>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginCard;
