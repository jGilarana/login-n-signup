import './Footer.css'

const Footer = () => {
  return (
    <div className='footer'>
      <h1>Reboot Academy Comp. </h1>
    </div>
  )
}

export default Footer
