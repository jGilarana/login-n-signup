import { Link } from 'react-router-dom'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
<Link to={'/'}>
  <img src='https://www.conector.com/wp-content/uploads/logo-rb.png'></img>
</Link>
      
      <h1 className='headerText'>Coding for coders since 2020</h1>
    </div>
  )
}

export default Header
