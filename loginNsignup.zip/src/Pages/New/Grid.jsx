import { Box } from '@mui/material'
import './New.css'

const Grid = () => {
  return (
    <div className='grid-container'>
    <Box sx={{flexGrow: 1}}>    
    </Box>
    </div>
  )
}

export default Grid